morning <- read.csv("datasets/morning_person.csv")

attach(morning)

library(ggplot2)
df = data.frame(x = rnorm(100), x2 = rnorm(100, mean=2))

g = ggplot(morning, aes(morning$Martin)) + geom_histogram( aes(x = morning$Martin, y = ..density..),
                                         binwidth = diff(range(morning$Martin))/7, fill="blue") + 
  geom_histogram( aes(x = morning$Kleinsmith, y = -..density..), binwidth = diff(range(morning$Martin))/7, fill= "green")
print(g)


## using base
h1 = hist(morning$Martin, plot=FALSE)
h2 = hist(morning$Kleinsmith, plot=FALSE)
h2$counts = - h2$counts
hmax = max(h1$counts)
hmin = min(h2$counts)
X = c(h1$breaks, h2$breaks)
xmax = max(X)
xmin = min(X)
plot(h1, ylim=c(hmin, hmax), 
     col="green", 
     xlim=c(xmin, xmax),
     main="Back to Back Histogram of\n Are You A MORNING PERSON?",
     xlab="Rating Scale Value\n 1 means not a morning person at all")
lines(h2, col="blue")

morning <- read.csv("datasets/morning2.csv")
library(Hmisc)
options(digits=0)
par(cex.lab=1.5)
bbh1 <- histbackback(split(morning$morning,morning$instructor), 
                     main = 'Back to Back Histogram',
                     ylab="Rating")
#! just adding color
barplot(-bbh1$left, col="red" , horiz=TRUE, space=0, add=TRUE, axes=FALSE)
barplot(bbh1$right, col="blue", horiz=TRUE, space=0, add=TRUE, axes=FALSE)


