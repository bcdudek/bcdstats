#initialize
require(datasets)
require(shiny)

#helper function (convert vector to named list)
namel<-function (vec){
      tmp<-as.list(vec)
      names(tmp)<-as.character(unlist(vec))
      tmp
    }

aron1_5 <- as.data.frame(read.csv("datasets/arontable1_5.csv"))
mouse1 <- as.data.frame(read.csv("datasets/amount.csv"))
morning1 <- as.data.frame(read.csv("datasets/morning_person.csv"))
names(morning1) <- c("Martin 1:15 PM section", "Kleinsmith 8:45 AM section", "Combined Data from both sections")
faithful2 <- faithful
names(faithful2) <- c("Eruption Duration (min)","Eruption Interval (min)")

#source("eahist.R")


